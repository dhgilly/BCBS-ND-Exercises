package bcbsnd;

import java.util.Scanner;

public class login {

	public String getlogin() {
	       System.out.println("Leave/Vacation Request Login Screen");
	        System.out.println();

	        Scanner sc = new Scanner(System.in);
	        String loginValid = "n";
	        String choice = "y";
	            // get input from user
	        while (choice.equalsIgnoreCase("y")) {
	            System.out.print("Enter UserID: ");
	            String userid = sc.nextLine();
	            System.out.print("Enter Password: ");
	            String password = sc.nextLine();

	            // test for valid userid and password in database. 
	            
	            if (not testSuccessful) {

	            // see if the user wants to try again         
	            System.out.print("Invalid userID or Password.  Try Again? (y/n): ");
	            choice = sc.nextLine();
	            System.out.println();
	        } else
		        loginValid = "y";

	     }
	        sc.close();
	        return loginValid;
	    }
	}