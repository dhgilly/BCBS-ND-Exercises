package bcbsnd;

import java.sql.Connection;
import java.sql.Date;
import java.util.Calendar;
import java.util.Scanner;

public class leaveVacationRequest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		login lgn = new login();
		String loginPassed = lgn.getlogin();
		if (loginPassed.equalsIgnoreCase("n"))
			System.exit(0);
		String inputAnother = "y";
		
		while (inputAnother.equalsIgnoreCase("y")){
			getEmployeeRequestInfo();
		}
	}
	
	
		public static void getEmployeeRequestInfo() {
			Scanner sc = new Scanner(System.in);
			System.out.println("Employee ID: ");
			String emplid = sc.nextLine();
			System.out.println("Begin Date: ");
			String beginDate = sc.nextLine();
			System.out.println("Return Date: ");
			String returnDate = sc.nextLine();
			System.out.println("Purpose of Time Off: ");
			String purpose = sc.nextLine();
			
			insertRequestInfo(emplid, beginDate, returnDate, purpose);
		}
	

public static void insertRequestInfo(String emplid, String beginDate, String returnDate, String purpose){
	Class.forName(driver);
//  System.out.println("Driver loaded...");

  Connection con=DriverManager.getConnection(url, "userid", "password");
//  System.out.println("Connected to the database");

	Statement st=con.createStatement();
	Date myDate = (Date) Calendar.getInstance().getTime();
	 st.executeUpdate ("INSERT INTO vacationRequests(employeeID, dateOfRequest, startingDate, returnDate, purposeOfTimeOff) VALUES ('"
			 + emplid
			 + "''"
			 + myDate
			 + "''"
			 + beginDate
			 + "''"
			 + returnDate
			 + "''"
			 + purpose
			 + "'')");
	con.close();
}
}
