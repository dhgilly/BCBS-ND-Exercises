package bubbleSort2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class bubbleSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> ar1 = new ArrayList<String>(40);
		FileRead(ar1);
		int numOfNames = ar1.size();
		System.out.println("There are " + numOfNames + " names in the list.");

		for (int c = 0; c < numOfNames - 1; c++) {
			for (int d = c + 1; d < numOfNames; d++) {
				if (ar1.get(c).compareToIgnoreCase(ar1.get(d)) > 0) {
					String temp = ar1.get(c);
					ar1.set(c, ar1.get(d));
					ar1.set(d, temp);
				}
			}
		}
		for (String temp : ar1) {
			System.out.println(temp);
		}

	}

	public static ArrayList FileRead(ArrayList ar) {

		String line;
		try {
			BufferedReader in = new BufferedReader(new FileReader("c:\\temp\\fileOfNames.txt"));
			for (int i = 1; i <= 20; i++) {
				line = in.readLine();
				int comma = line.indexOf(",");
				String Lname = line.substring(0, comma).trim();
				String Fname = line.substring(comma + 1).trim();
				String name = Fname.concat(" ");
				name = name.concat(Lname);
				// System.out.println(name);
				ar.add(name);
			}
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ar;
	}
}
